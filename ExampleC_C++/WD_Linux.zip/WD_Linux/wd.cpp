#include <string>
#include <cstring>
#include <iostream>
#include <chrono>
#include <ctime>
#include <thread>

static void AddLog(char* folder ,const char* string)
{
    FILE* f;
    char log_file[512];
    char log_msg[512];
    const char* filename = "watchdog.log";

    time_t t = time(NULL);
    struct tm tm = *localtime(&t);


    sprintf(log_msg,"[%d-%d-%d %d:%d:%d]: %s\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, string);


    sprintf(log_file, "%s/%s", folder, filename);

    f = fopen(log_file,"ab");
    if( !f ){
    	printf("log_file: %s [open failed]", log_file);
    	sprintf(log_file, "./watchdog.log");
    	f = fopen(log_file,"ab");
    	printf("%s\n",log_msg);
    }

    if( f ){
    	fwrite(log_msg,1,strlen(log_msg),f);
    	fflush(f);
    	fclose(f);
    }
}

int get_pid(char* program)
{
    char line[1024];
    char command[128];
    FILE *cmd;
    pid_t pid;

    pid = 0;
    sprintf(line, "");
#if 1
    sprintf(command,"ps -edaf | grep \"%s\"  | grep -v \"grep \\|wd\" | awk '{ print $2 }'", program);
    cmd = popen(command, "r");
    fgets(line, 127, cmd);
    pid = strtoul(line, NULL, 10);
#else
    sprintf(command,"pidof %s", program);
    cmd = popen(command, "r");
    fgets(line, 6, cmd);
    pid = strtoul(line, NULL, 10);
#endif
    printf("pid = %u", pid);
    pclose(cmd);

    return pid;
}

int main (int argc, char *argv[])
{
    // parametri:
    // 1) nome processo da monitorare
    // 2) timeout di controllo stato in secondi
    // 3) path in cui salvare i file di log
    // 4) percorso completo del processo da rilanciare in caso non venga trovato in esecuzione il processo
	using namespace std::chrono_literals;
    int pid;

    if ( argc < 5){
    	printf("usage: %s <process_name> <sec_timeout> <logdir> <launch cmd>", argv[0] );
    	return 1;
    }
    std::chrono::seconds delay(atoi(argv[2]));

    while(true)
    {
		pid=get_pid(argv[1]);
		if(pid == 0)
		{
			printf("\nprocess [%s] ...restart", argv[1]);
			AddLog(argv[3],"Application_not_running");

			std::this_thread::sleep_for(1s);

			char cmd[512];
			sprintf(cmd,"%s &", argv[4]);
			printf("cmd:[%s]\n", cmd);
			system(cmd);
		}
		else
		{
			printf("\nprocess [%i][%s] works correctly",pid, argv[1]);
		}

		std::this_thread::sleep_for(delay);
    }

    return 1;
}

